from flask import Flask, render_template, request, jsonify, send_from_directory
import numpy as np
from copy import deepcopy
import os

app = Flask(__name__)

block_max = 10

PLAYER_INITIAL = {
    "HP": 150,
    "attack": 17,
    "defense": 10,
}

ENEMY_INITIAL = {
    "HP": 150,
    "attack": 20,
    "defense": 10,
}

cost = {"攻撃": 1, "防御": 1, "侮辱": 1, "隠れる": 1, "強撃": 2, "ためる": 1}

# グローバル状態
game_state = {
    "player": deepcopy(PLAYER_INITIAL),
    "enemy": deepcopy(ENEMY_INITIAL),
    "player_actions": [],
    "battle_logs": [],
    "turn_number": 1,
    "all_turn_logs": [],
    "game_over": False,
    "winner": None,
    "current_log_index": 0,
    "showing_logs": False
}

def total_cost(turn):
    s = 0
    for a in turn:
        if isinstance(a, str):
            s += cost[a]
        elif isinstance(a, tuple):
            s += cost[a[1]]
        elif isinstance(a, dict):
            s += cost[a["name"]]
        else:
            raise TypeError("未知のアクション要素です")
    return s

def add_action(turn, action):
    if action not in cost:
        raise ValueError("未知の行動です")
    now = total_cost(turn)
    nxt = now + cost[action]
    if nxt <= block_max:
        turn.append((nxt, action))
        return True
    return False

def make_enemy_action():
    turn = []
    actions = list(cost.keys())
    while True:
        remain = block_max - total_cost(turn)
        candidates = [a for a in actions if cost[a] <= remain]
        if not candidates:
            break
        pick = np.random.choice(candidates)
        now = total_cost(turn)
        nxt = now + cost[pick]
        turn.append((nxt, pick))
    return turn

def _clamp_int(x):
    return int(max(0, round(x)))

def _damage(attacker, defender, mult=1.0):
    atk = attacker["attack"] * mult
    dmg = _clamp_int(atk - defender["defense"])
    return max(0, dmg)

def action(player, enemy, player_action, enemy_action):
    logs = []
    for index in range(1, block_max + 1):
        p_act = next((a for a in player_action if a[0] == index), None)
        e_act = next((a for a in enemy_action if a[0] == index), None)

        p_name = p_act[1] if p_act else None
        e_name = e_act[1] if e_act else None

        if not p_name and not e_name:
            continue

        log_entry = {
            "index": index,
            "player_action": p_name,
            "enemy_action": e_name,
            "events": []
        }

        p_hide = (p_name == "隠れる")
        e_hide = (e_name == "隠れる")

        if p_hide:
            log_entry["events"].append("プレイヤーは隠れている")
        if e_hide:
            log_entry["events"].append("敵は隠れている")

        if p_name == "防御":
            old_def = player["defense"]
            player["defense"] = _clamp_int(player["defense"]*1.1 +  1)
            log_entry["events"].append(f"プレイヤーの防御力上昇: {old_def} → {player['defense']}")
        if e_name == "防御":
            old_def = enemy["defense"]
            enemy["defense"] = _clamp_int(enemy["defense"]*1.1 +  1)
            log_entry["events"].append(f"敵の防御力上昇: {old_def} → {enemy['defense']}")

        if p_name == "ためる":
            old_att = player["attack"]
            player["attack"] = _clamp_int(player["attack"] * 1.1 + 2)
            log_entry["events"].append(f"プレイヤーの攻撃力上昇: {old_att} → {player['attack']}")
        if e_name == "ためる":
            old_att = enemy["attack"]
            enemy["attack"] = _clamp_int(enemy["attack"] * 1.1 + 2)
            log_entry["events"].append(f"敵の攻撃力上昇: {old_att} → {enemy['attack']}")

        if p_name == "侮辱":
            old_att = enemy["attack"]
            enemy["attack"] = _clamp_int(enemy["attack"] - (player["attack"] / 10))
            log_entry["events"].append(f"プレイヤーの侮辱で敵攻撃力減少: {old_att} → {enemy['attack']}")
        if e_name == "侮辱":
            old_att = player["attack"]
            player["attack"] = _clamp_int(player["attack"] - (enemy["attack"] / 10))
            log_entry["events"].append(f"敵の侮辱でプレイヤー攻撃力減少: {old_att} → {player['attack']}")

        if p_name in ("攻撃", "強撃"):
            mult = 2.2 if p_name == "強撃" else 1.0
            if not e_hide:
                dealt = _damage(player, enemy, mult)
                enemy["HP"] = _clamp_int(enemy["HP"] - dealt)
                log_entry["events"].append(f"プレイヤーの{p_name}: 敵に{dealt}ダメージ")
            else:
                log_entry["events"].append("敵が隠れていたため攻撃無効")

        if e_name in ("攻撃", "強撃"):
            mult = 2.2 if e_name == "強撃" else 1.0
            if not p_hide:
                dealt = _damage(enemy, player, mult)
                player["HP"] = _clamp_int(player["HP"] - dealt)
                log_entry["events"].append(f"敵の{e_name}: プレイヤーに{dealt}ダメージ")
            else:
                log_entry["events"].append("プレイヤーが隠れていたため攻撃無効")

        log_entry["player_stats"] = dict(player)
        log_entry["enemy_stats"] = dict(enemy)
        logs.append(log_entry)

        if player["HP"] <= 0 or enemy["HP"] <= 0:
            break
    return logs

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/game_state')
def get_game_state():
    return jsonify({
        "player": game_state["player"],
        "enemy": game_state["enemy"],
        "player_actions": game_state["player_actions"],
        "battle_logs": game_state["battle_logs"],
        "turn_number": game_state["turn_number"],
        "all_turn_logs": game_state["all_turn_logs"],
        "game_over": game_state["game_over"],
        "winner": game_state["winner"],
        "current_log_index": game_state["current_log_index"],
        "showing_logs": game_state["showing_logs"],
        "costs": cost,
        "block_max": block_max
    })

@app.route('/api/add_action', methods=['POST'])
def add_player_action():
    action_name = request.json.get('action')
    if add_action(game_state["player_actions"], action_name):
        return jsonify({"success": True, "player_actions": game_state["player_actions"]})
    else:
        return jsonify({"success": False, "error": f"コスト不足で{action_name}を追加できません"})

@app.route('/api/reset_actions', methods=['POST'])
def reset_actions():
    game_state["player_actions"] = []
    return jsonify({"success": True})

@app.route('/api/reset_game', methods=['POST'])
def reset_game():
    game_state["player"] = deepcopy(PLAYER_INITIAL)
    game_state["enemy"] = deepcopy(ENEMY_INITIAL)
    game_state["player_actions"] = []
    game_state["battle_logs"] = []
    game_state["turn_number"] = 1
    game_state["all_turn_logs"] = []
    game_state["game_over"] = False
    game_state["winner"] = None
    game_state["current_log_index"] = 0
    game_state["showing_logs"] = False
    return jsonify({"success": True})

@app.route('/api/start_battle', methods=['POST'])
def start_battle():
    if game_state["game_over"]:
        return jsonify({"success": False, "error": "ゲーム終了済みです。ゲームをリセットしてください"})
        
    if not game_state["player_actions"]:
        return jsonify({"success": False, "error": "プレイヤーのアクションが設定されていません"})
    
    enemy_actions = make_enemy_action()
    player_copy = deepcopy(game_state["player"])
    enemy_copy = deepcopy(game_state["enemy"])
    
    logs = action(player_copy, enemy_copy, game_state["player_actions"], enemy_actions)
    
    # ターンログを保存
    turn_log = {
        "turn": game_state["turn_number"],
        "player_actions": game_state["player_actions"].copy(),
        "enemy_actions": enemy_actions.copy(),
        "logs": logs.copy(),
        "turn_start_player": deepcopy(game_state["player"]),
        "turn_start_enemy": deepcopy(game_state["enemy"]),
        "turn_end_player": deepcopy(player_copy),
        "turn_end_enemy": deepcopy(enemy_copy)
    }
    game_state["all_turn_logs"].append(turn_log)
    
    game_state["player"] = player_copy
    game_state["enemy"] = enemy_copy
    game_state["battle_logs"] = logs
    
    # 戦闘結果の判定だけ行い、ターン進行は別で管理
    result = "continue"
    if game_state["player"]["HP"] <= 0:
        result = "player_lose"
        game_state["game_over"] = True
        game_state["winner"] = "enemy"
    elif game_state["enemy"]["HP"] <= 0:
        result = "player_win"
        game_state["game_over"] = True
        game_state["winner"] = "player"
    
    # ログ表示用の状態管理
    game_state["current_log_index"] = 0
    game_state["showing_logs"] = True
    
    return jsonify({
        "success": True,
        "enemy_actions": enemy_actions,
        "logs": logs,
        "result": result,
        "turn_number": game_state["turn_number"]
    })

@app.route('/api/next_log', methods=['POST'])
def next_log():
    if not game_state["showing_logs"]:
        return jsonify({"success": False, "error": "ログ表示中ではありません"})
    
    game_state["current_log_index"] += 1
    
    # 全ログを表示し終えた場合
    if game_state["current_log_index"] >= len(game_state["battle_logs"]):
        game_state["showing_logs"] = False
        game_state["current_log_index"] = 0
        
        # ゲーム終了でなければ次のターンへ
        if not game_state["game_over"]:
            game_state["turn_number"] += 1
            game_state["player_actions"] = []
            game_state["battle_logs"] = []
        
        return jsonify({"success": True, "finished": True})
    
    return jsonify({"success": True, "finished": False})

@app.route('/api/skip_logs', methods=['POST'])
def skip_logs():
    if not game_state["showing_logs"]:
        return jsonify({"success": False, "error": "ログ表示中ではありません"})
    
    game_state["showing_logs"] = False
    game_state["current_log_index"] = 0
    
    # ゲーム終了でなければ次のターンへ
    if not game_state["game_over"]:
        game_state["turn_number"] += 1
        game_state["player_actions"] = []
        game_state["battle_logs"] = []
    
    return jsonify({"success": True})

if __name__ == '__main__':
    # テンプレートディレクトリを作成
    os.makedirs('templates', exist_ok=True)
    app.run(debug=True, host='0.0.0.0', port=8080)